<?php include 'includes/config.php'?>
<?php //include 'header.php'
?>
<?php get_header();?>


<p>Clever content goes here!</p>  
<p>Clever content goes here!</p>  
<p>Clever content goes here!</p>  
<p>Clever content goes here!</p>  
<p>Clever content goes here!</p>  
<p>Clever content goes here!</p>  
<p>Clever content goes here!</p>  

<?php get_footer();?>