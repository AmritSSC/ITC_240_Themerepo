<?php include 'config.php'?>
<?php include 'header.php'?>

<p>Clever content goes here!</p>  
<p>Clever content goes here!</p>  
<p>Clever content goes here!</p>  
<p>Clever content goes here!</p>  
<p>Clever content goes here!</p>  
<p>Clever content goes here!</p>  
<p>Clever content goes here!</p>  

<?php include 'footer.php'?>