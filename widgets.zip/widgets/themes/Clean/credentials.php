<?php
//credentials.php

define('DB_NAME','amritd1_school_db');
define('DB_USER','amritd1');
define('DB_PASSWORD','Peg2door2!');
define('DB_HOST','mysql.degreefied.com');

?>