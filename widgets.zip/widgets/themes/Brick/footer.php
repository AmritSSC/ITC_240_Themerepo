 <!-- footer ends here -->
        </div>
    </div>
    <!-- /.container -->

    <footer class="bg-faded text-center py-5">
      <div class="container">
        <p class="m-0">Copyright &copy; Your Website 2017 <?=$config->adminWidget;?></p>
      </div>
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="<?=$config->theme_virtual?>vendor/jquery/jquery.min.js"></script>
    <script src="<?=$config->theme_virtual?>vendor/popper/popper.min.js"></script>
    <script src="<?=$config->theme_virtual?>vendor/bootstrap/js/bootstrap.min.js"></script>

  </body>

</html>
