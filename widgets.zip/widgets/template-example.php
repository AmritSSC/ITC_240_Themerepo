<?php include 'includes/config.php'?>
<?php get_header()?>
<h3>Name of page</h3>
<p>Clever content goes here</p>
<p>Clever content goes here</p>
<p>Clever content goes here</p>
<p>Clever content goes here</p>
<p>Clever content goes here</p>
<p>Clever content goes here</p>
<p>Clever content goes here</p>
<p>Clever content goes here</p>
<p>Clever content goes here</p>
<p>Clever content goes here</p>
<?php get_footer()?>